function minLenAlerta(i){
  Swal.fire('Está faltando ' + i + ' caracteres.');
}